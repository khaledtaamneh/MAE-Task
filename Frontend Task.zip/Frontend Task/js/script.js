$(document).ready(function () {

  $('.following-data').hide();


  $('.followers-div').click(function () {
      $('.followers-data').show();
      $('.following-data').hide();
      $(this).addClass('active-tab');
      $('.following-div').removeClass('active-tab');
      $("#followers-header").css("color" , "#fff !important");
      $("#following-header").css("color" , "#b1b1b1 !important");
  });

  $('.following-div').click(function () {
      $('.followers-data').hide();
      $('.following-data').show();
      $(this).addClass('active-tab');
      $('.followers-div').removeClass('active-tab');
      $("#following-header").css("color" , "#fff !important");
      $("#followers-header").css("color" , "#b1b1b1 !important");
  });


});








const corsProxyUrl = 'https://cors-anywhere.herokuapp.com/';
const apiUrl = 'https://lavishride.com/front_end_task';

fetch(`${corsProxyUrl}${apiUrl}`)
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    console.log(data); 

    document.getElementById('followers-count').textContent = data.followers.length;
    document.getElementById('followers-count2').textContent = data.followers.length;
    document.getElementById('blue2').textContent = data.followers.length;
    document.getElementById('blue').textContent = data.followers.length;
    document.getElementById('following-count').textContent = data.followers.length;
    document.getElementById('following-count2').textContent = data.followers.length;




    const followersContainer = document.getElementById('followers-id');
    followersContainer.innerHTML = '';

  
    if (data.followers.length > 0) {
      data.followers.forEach(follower => {
        const followerElement = document.createElement('div');
        followerElement.className = 'all-followers';

        const usernameDiv = document.createElement('div');
        usernameDiv.className = 'followers-username-div';

        const userImage = document.createElement('img');
        userImage.src = follower.image;

        const usernameWrapperDiv = document.createElement('div');

        const usernameP = document.createElement('p');
        usernameP.textContent = follower.tag;

        const usernameHeading = document.createElement('h5');
        usernameHeading.className = 'followers-username';
        usernameHeading.textContent = follower.name;
        
        const createdDiv = document.createElement('div');
        createdDiv.className = 'created';

        const createdP = document.createElement('p');
        createdP.textContent = 'Created';

        const createdSpan = document.createElement('span');
        createdSpan.textContent = follower.nfts;

        const followButtonDiv = document.createElement('div');
        followButtonDiv.className = 'follow-button';

        const followButton = document.createElement('button');
        followButton.textContent = 'FOLLOW +';
        usernameWrapperDiv.appendChild(usernameHeading);
        usernameWrapperDiv.appendChild(usernameP);

        usernameDiv.appendChild(userImage);
        usernameDiv.appendChild(usernameWrapperDiv);

        createdDiv.appendChild(createdP);
        createdDiv.appendChild(createdSpan);

        followButtonDiv.appendChild(followButton);

        
        followerElement.appendChild(usernameDiv);
        followerElement.appendChild(createdDiv);
        followerElement.appendChild(followButtonDiv);

        followersContainer.appendChild(followerElement);
      });
    }   else {
      followersContainer.textContent = 'No followers available or unexpected data structure.';
    }
  })
  .catch(error => console.error('Error fetching data:', error));






  fetch(`${corsProxyUrl}${apiUrl}`)
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    console.log(data); 

    const followingContainer = document.getElementById('following-id');
    followingContainer.innerHTML = '';


  if(data.following.length > 0) 
    {

      const followingContainer = document.getElementById('following-id');
      followingContainer.innerHTML = '';
  
    
      if (data.following.length > 0) {
        data.following.forEach(follower => {
          const followerElement = document.createElement('div');
          followerElement.className = 'all-following';
  
          
  
  
          const usernameDiv = document.createElement('div');
          usernameDiv.className = 'followers-username-div';

          const userImage = document.createElement('img');
          userImage.src = follower.image;
      
          const usernameWrapperDiv = document.createElement('div');

          const usernameP = document.createElement('p');
          usernameP.textContent = follower.tag;
  
          const usernameHeading = document.createElement('h5');
          usernameHeading.className = 'followers-username';
          usernameHeading.textContent = follower.name;
          
          const createdDiv = document.createElement('div');
          createdDiv.className = 'created';
  
          const createdP = document.createElement('p');
          createdP.textContent = 'Created';
  
          const createdSpan = document.createElement('span');
          createdSpan.textContent = follower.nfts;
  
          const followButtonDiv = document.createElement('div');
          followButtonDiv.className = 'follow-button';
  
          const followButton = document.createElement('button');
          followButton.textContent = 'FOLLOW +';
  
          usernameWrapperDiv.appendChild(usernameHeading);
          usernameWrapperDiv.appendChild(usernameP);

          usernameDiv.appendChild(userImage);
          usernameDiv.appendChild(usernameWrapperDiv);
  
          createdDiv.appendChild(createdP);
          createdDiv.appendChild(createdSpan);
  
          followButtonDiv.appendChild(followButton);
  
          
          followerElement.appendChild(usernameDiv);
          followerElement.appendChild(createdDiv);
          followerElement.appendChild(followButtonDiv);
  
          followingContainer.appendChild(followerElement);
        });

      }
    } else {
      followingContainer.textContent = 'No followers available or unexpected data structure.';
    }
  })
  .catch(error => console.error('Error fetching data:', error));
    
    